/**
 Contains the main {@link org.jsoup.Jsoup} class, which provides convenient static access to the jsoup functionality. 
 */
package org.jsoup;